package demo.hogwarts;

/**
 * This class represent a house in Hogwarts
 * 
 * @author emalianakasmuri
 *
 */
public class House {
	
	private int houseId;
	private String name;
	private String founder;
	
	public int getHouseId() {
		return houseId;
	}
	public void setHouseId(int houseId) {
		this.houseId = houseId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getFounder() {
		return founder;
	}
	public void setFounder(String founder) {
		this.founder = founder;
	}
	

}
